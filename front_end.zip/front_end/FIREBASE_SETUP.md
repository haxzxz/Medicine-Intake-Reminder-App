# Firebase Setup Guide — Zam

You need a Firebase project to enable Google + Facebook login.

---

## Step 1 — Create a Firebase project

1. Go to https://console.firebase.google.com/
2. Click **Add project** → name it "Zam" → Continue
3. Disable Google Analytics (optional) → **Create project**

---

## Step 2 — Add your Android app to Firebase

1. In your Firebase project, click the **Android icon** (⟨/⟩)
2. Package name: `com.example.zam_medicine_reminder`
3. App nickname: `Zam`
4. Click **Register app**
5. **Download `google-services.json`**
6. Put it here: `zam_ai_app/android/app/google-services.json`
7. Click Next → Next → Continue to console

---

## Step 3 — Enable Google Sign-In

1. In Firebase Console → **Authentication** → **Sign-in method**
2. Click **Google** → Enable → Set support email → **Save**

---

## Step 4 — Enable Facebook Sign-In

1. Go to https://developers.facebook.com/ → **My Apps** → **Create App**
2. Choose **Consumer** → name it "Zam" → Create
3. In Facebook dashboard → **Settings → Basic** → copy your:
   - **App ID**
   - **App Secret**
4. Back in Firebase → **Authentication → Sign-in method → Facebook**
5. Paste App ID and App Secret → Enable → Save
6. Copy the **OAuth redirect URI** Firebase shows you
7. Back in Facebook → **Facebook Login → Settings** → paste the redirect URI → Save

---

## Step 5 — Add Facebook credentials to AndroidManifest.xml

Open `android/app/src/main/AndroidManifest.xml` and add inside `<application>`:

```xml
<meta-data
    android:name="com.facebook.sdk.ApplicationId"
    android:value="@string/facebook_app_id"/>
<meta-data
    android:name="com.facebook.sdk.ClientToken"
    android:value="@string/facebook_client_token"/>
```

Then create `android/app/src/main/res/values/strings.xml`:

```xml
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="facebook_app_id">YOUR_FACEBOOK_APP_ID</string>
    <string name="facebook_client_token">YOUR_FACEBOOK_CLIENT_TOKEN</string>
</resources>
```

Get the Client Token from Facebook → **Settings → Advanced → Client Token**

---

## Step 6 — Add google-services plugin to build.gradle

In `android/build.gradle`, add to `buildscript > dependencies`:
```gradle
classpath 'com.google.gms:google-services:4.4.2'
```

In `android/app/build.gradle`, add at the bottom:
```gradle
apply plugin: 'com.google.gms.google-services'
```

---

## Step 7 — Update SHA-1 fingerprint (for Google Sign-In)

Run this in terminal:
```
keytool -list -v -keystore ~/.android/debug.keystore -alias androiddebugkey -storepass android -keypass android
```
Copy the SHA-1 value → Firebase Console → Project Settings → Your App → Add fingerprint

---

## Done! Run the app:
```
flutter pub get
flutter run
```
