# Zam AI — Smart Medicine Reminder (Flutter)

Zam is now powered by Claude AI. Talk to it casually and it understands everything.

---

## What's new in this AI version

| Feature | Before | Now |
|---|---|---|
| Language understanding | Simple regex parser | Claude AI — understands anything |
| Casual speech | "Remind me to take X at 8pm" only | "yo zam pills 8ish", "meds tonite", "after dinner" |
| Conversation memory | None | Full session memory — "change my last reminder" |
| Health info | None | Tips on food interactions, timing, storage |
| Managing reminders | Manual only | "what did I set?", "clear everything", "delete vitamin reminder" |

---

## Setup (Step by Step)

### Step 1 — Get your Anthropic API key
1. Go to https://console.anthropic.com/
2. Sign up (free) and go to API Keys
3. Click "Create Key" — copy it

### Step 2 — Install Flutter
1. Go to https://flutter.dev/docs/get-started/install
2. Follow for your OS. Run `flutter doctor` to verify.

### Step 3 — Set up the project
```
cd zam_ai_app
flutter pub get
flutter run
```

### Step 4 — Add your API key in the app
- Tap the 🔑 key icon in the top bar
- Paste your API key
- It's saved securely on your device

---

## Try these phrases

- `"yo zam pills 8ish"`
- `"remind me to take biogesic tonight"`
- `"what meds do I have set?"`
- `"change my last reminder to 9pm"`
- `"is it ok to take ibuprofen on an empty stomach?"`
- `"clear all my reminders"`
- `"remind me in 5 minutes"` (great for testing)

---

## Project Structure

```
lib/
  main.dart                         ← App entry, notifications, timezone fix
  models/
    reminder.dart                   ← Data model
  services/
    claude_service.dart             ← Claude AI API calls + conversation memory
    notification_service.dart       ← Schedule real phone alarms
    storage_service.dart            ← Persist reminders + API key
  screens/
    home_screen.dart                ← Full chat UI with AI integration
  widgets/
    chat_bubble.dart                ← Message bubbles
    reminder_card.dart              ← Reminder card in chat
    api_key_dialog.dart             ← API key entry dialog
android/
  app/src/main/
    AndroidManifest.xml             ← All permissions + notification receivers
    kotlin/.../MainActivity.kt      ← Flutter entry point
    res/...                         ← Styles + launch background
  build.gradle / settings.gradle    ← Build config with desugaring + minSdk 21
```

---

## Troubleshooting

**"Invalid API key"** → Double-check you copied the full key from console.anthropic.com

**Notifications not showing** → On Android 13+, allow notifications when the app first asks. You can also say "test notification" in chat.

**Mic not working** → Use a real phone (emulators block mic). Check mic permission in Settings.

**Build fails** → Run `flutter doctor` and fix any issues. Most common: `flutter doctor --android-licenses`
