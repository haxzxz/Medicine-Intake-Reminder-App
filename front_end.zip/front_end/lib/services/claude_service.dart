import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import '../models/reminder.dart';

class ZamResponse {
  final String message;
  final String? action;
  final ReminderIntent? reminder;
  final List<String> suggestions;
  final String? error;

  const ZamResponse({
    required this.message,
    this.action,
    this.reminder,
    this.suggestions = const [],
    this.error,
  });

  factory ZamResponse.error(String msg) =>
      ZamResponse(message: msg, error: msg);
}

class ReminderIntent {
  final String name;
  final String time;

  const ReminderIntent({required this.name, required this.time});

  factory ReminderIntent.fromJson(Map<String, dynamic> json) => ReminderIntent(
        name: json['name'] as String? ?? 'Medicine',
        time: json['time'] as String? ?? '08:00',
      );
}

class ClaudeService {
  // ── API key encapsulated — never exposed to UI ─────────────────────────────
  // To change the key: update this constant and rebuild the app.
  // This is the only place the key lives.
  static const String _apiKey = 'YOUR_GEMINI_API_KEY_HERE';

  static const String _model = 'gemini-2.0-flash';

  static String get _url =>
      'https://generativelanguage.googleapis.com/v1beta/models/$_model:generateContent?key=$_apiKey';

  // ── Rate limiting: per-instance cooldown ───────────────────────────────────
  // Minimum gap between requests — prevents bursting even if the user types fast
  static const Duration _minRequestGap = Duration(seconds: 3);
  DateTime? _lastRequestTime;

  // Queue: only ONE request in flight at a time
  bool _requestInFlight = false;
  final List<_QueuedRequest> _queue = [];

  // Retry on 429 with exponential backoff
  static const int _maxRetries = 2;
  static const Duration _retryBase = Duration(seconds: 5);

  // Conversation history — trimmed to last 8 turns to save tokens
  final List<Map<String, dynamic>> _history = [];
  static const int _maxHistoryTurns = 8;

  // ── System prompt ──────────────────────────────────────────────────────────

  String _buildSystemPrompt(List<Reminder> reminders) {
    final now = DateTime.now();
    final timeFmt = DateFormat('h:mm a');
    final dateFmt = DateFormat('EEEE, MMMM d, yyyy');

    final activeReminders = reminders.isEmpty
        ? 'None'
        : reminders
            .map((r) =>
                '- ${r.medicineName} at ${timeFmt.format(r.time)} (${r.timeUntilLabel})')
            .join('\n');

    return '''You are Zam, a warm, smart, casual AI medicine reminder assistant.
Today is ${dateFmt.format(now)}, current time is ${timeFmt.format(now)}.

ACTIVE REMINDERS:
$activeReminders

YOUR CAPABILITIES:
1. SET REMINDERS — understand casual language: "pills 8ish", "meds tonite 9", "biogesic 7pm"
2. MANAGE REMINDERS — "what do I have set?", "clear everything", "delete vitamin reminder"
3. HEALTH INFO — brief helpful tips (food interactions, storage, timing). Say "consult your doctor" for symptoms.
4. CONVERSATION MEMORY — remember everything said this session; handle follow-ups naturally

RESPONSE FORMAT — respond ONLY with valid JSON, no markdown, no backticks:
{
  "message": "warm brief reply, 2-3 sentences. Use \\n for newlines. Emoji ok.",
  "action": null,
  "reminder": null,
  "suggestions": ["chip 1", "chip 2", "chip 3"]
}

To set a reminder:
{ "message": "...", "action": "set_reminder", "reminder": { "name": "Medicine Name", "time": "HH:MM" }, "suggestions": [...] }

To delete all:
{ "message": "...", "action": "delete_all", "reminder": null, "suggestions": [...] }

TIME RULES:
- "8ish" → 08:00 if morning context, 20:00 if evening context
- "tonight/evening/pm" → PM hours
- "morning" → 08:00, "noon/lunch" → 12:00, "night/bedtime" → 21:00, "after dinner" → 19:00
- Bare 1-6 → assume PM. Bare 7-11 → prefer AM unless context says PM
- Always output 24-hour "HH:MM"

MEDICINE NAME RULES:
- Extract real name: "Biogesic", "Vitamin C", "Metformin"
- "my pills/meds" with no name → "Medicine"
- Capitalise correctly

PERSONALITY: casual, warm, brief. Don't repeat reminder details (the card shows them).''';
  }

  // ── Public chat method ─────────────────────────────────────────────────────

  Future<ZamResponse> chat({
    required String userMessage,
    required List<Reminder> reminders,
  }) {
    final completer = Completer<ZamResponse>();
    _queue.add(_QueuedRequest(
      userMessage: userMessage,
      reminders: List.from(reminders),
      completer: completer,
    ));
    _processQueue();
    return completer.future;
  }

  void clearHistory() => _history.clear();

  // ── Queue ──────────────────────────────────────────────────────────────────

  void _processQueue() {
    if (_requestInFlight || _queue.isEmpty) return;
    _requestInFlight = true;

    final req = _queue.removeAt(0);

    // Enforce minimum gap between requests
    final now = DateTime.now();
    final gap = _lastRequestTime == null
        ? Duration.zero
        : now.difference(_lastRequestTime!);
    final wait = gap < _minRequestGap ? _minRequestGap - gap : Duration.zero;

    Future.delayed(wait, () => _executeWithRetry(req)).then((res) {
      req.completer.complete(res);
    }).catchError((e) {
      req.completer.complete(ZamResponse.error("Unexpected error: $e"));
    }).whenComplete(() {
      _requestInFlight = false;
      if (_queue.isNotEmpty) {
        Future.delayed(const Duration(milliseconds: 200), _processQueue);
      }
    });
  }

  // ── Retry with exponential backoff ─────────────────────────────────────────

  Future<ZamResponse> _executeWithRetry(_QueuedRequest req) async {
    for (int attempt = 0; attempt <= _maxRetries; attempt++) {
      if (attempt > 0) {
        final delay = _retryBase * (1 << (attempt - 1)); // 5s, 10s
        debugPrint('Rate limited. Waiting ${delay.inSeconds}s before retry $attempt');
        await Future.delayed(delay);
      }

      final res = await _doRequest(req);

      final isRateLimit = res.error != null &&
          (res.error!.contains('429') ||
              res.error!.toLowerCase().contains('quota') ||
              res.error!.toLowerCase().contains('rate'));

      if (!isRateLimit) return res;

      if (attempt == _maxRetries) {
        return ZamResponse.error(
            "Zam is getting too many requests right now 😅\nPlease wait about 30 seconds and try again.");
      }
    }
    return ZamResponse.error("Unexpected retry failure");
  }

  // ── Single HTTP request ────────────────────────────────────────────────────

  Future<ZamResponse> _doRequest(_QueuedRequest req) async {
    _lastRequestTime = DateTime.now();

    _history.add({
      'role': 'user',
      'parts': [{'text': req.userMessage}],
    });
    _trimHistory();

    try {
      final response = await http.post(
        Uri.parse(_url),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'system_instruction': {
            'parts': [{'text': _buildSystemPrompt(req.reminders)}]
          },
          'contents': _history,
          'generationConfig': {
            'temperature': 0.7,
            'maxOutputTokens': 500, // Keep short to save quota
            'responseMimeType': 'application/json',
          },
        }),
      ).timeout(const Duration(seconds: 30));

      if (response.statusCode == 429) {
        _history.removeLast();
        return ZamResponse.error('429 rate limit');
      }
      if (response.statusCode == 400) {
        _history.removeLast();
        final err = jsonDecode(response.body);
        final msg = err['error']?['message'] as String? ?? 'Bad request';
        return ZamResponse.error("Gemini error: $msg");
      }
      if (response.statusCode == 403) {
        _history.removeLast();
        return ZamResponse.error(
            "API key issue. Please contact the app developer.");
      }
      if (response.statusCode != 200) {
        _history.removeLast();
        return ZamResponse.error("Gemini error ${response.statusCode}");
      }

      final body = jsonDecode(response.body) as Map<String, dynamic>;
      final candidates = body['candidates'] as List?;
      if (candidates == null || candidates.isEmpty) {
        _history.removeLast();
        return ZamResponse.error("Empty response. Try again.");
      }

      final rawText =
          candidates[0]['content']?['parts']?[0]?['text'] as String? ?? '';

      _history.add({
        'role': 'model',
        'parts': [{'text': rawText}],
      });

      try {
        final clean = rawText.replaceAll(RegExp(r'```json|```'), '').trim();
        final parsed = jsonDecode(clean) as Map<String, dynamic>;

        ReminderIntent? intent;
        if (parsed['action'] == 'set_reminder' && parsed['reminder'] != null) {
          intent = ReminderIntent.fromJson(
              parsed['reminder'] as Map<String, dynamic>);
        }

        final rawSuggestions = parsed['suggestions'];
        final suggestions = rawSuggestions is List
            ? rawSuggestions.cast<String>()
            : <String>[];

        return ZamResponse(
          message: parsed['message'] as String? ?? rawText,
          action: parsed['action'] as String?,
          reminder: intent,
          suggestions: suggestions,
        );
      } catch (e) {
        debugPrint('JSON parse error: $e\nRaw: $rawText');
        return ZamResponse(message: rawText);
      }
    } on TimeoutException {
      _history.removeLast();
      return ZamResponse.error("Request timed out. Check your internet.");
    } catch (e) {
      _history.removeLast();
      debugPrint('Gemini error: $e');
      return ZamResponse.error("Could not reach Gemini. Check your connection.");
    }
  }

  // ── Trim history ───────────────────────────────────────────────────────────

  void _trimHistory() {
    final maxMessages = _maxHistoryTurns * 2;
    if (_history.length > maxMessages) {
      final excess = _history.length - maxMessages;
      _history.removeRange(0, excess % 2 == 0 ? excess : excess + 1);
    }
  }
}

class _QueuedRequest {
  final String userMessage;
  final List<Reminder> reminders;
  final Completer<ZamResponse> completer;

  _QueuedRequest({
    required this.userMessage,
    required this.reminders,
    required this.completer,
  });
}
