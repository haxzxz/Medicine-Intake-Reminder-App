class Reminder {
  final int id;
  final String medicineName;
  final DateTime time;
  final DateTime createdAt; // when the user set this reminder
  bool fired;

  Reminder({
    required this.id,
    required this.medicineName,
    required this.time,
    DateTime? createdAt,
    this.fired = false,
  }) : createdAt = createdAt ?? DateTime.now();

  bool get isPast => time.isBefore(DateTime.now());

  String get timeUntilLabel {
    final diff = time.difference(DateTime.now());
    if (diff.isNegative) return 'Fired!';
    if (diff.inHours > 0) return 'in ${diff.inHours}h ${diff.inMinutes % 60}m';
    if (diff.inMinutes > 0) return 'in ${diff.inMinutes}m ${diff.inSeconds % 60}s';
    return 'in ${diff.inSeconds}s';
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'medicineName': medicineName,
        'time': time.toIso8601String(),
        'createdAt': createdAt.toIso8601String(),
        'fired': fired,
      };

  factory Reminder.fromJson(Map<String, dynamic> json) => Reminder(
        id: json['id'] as int,
        medicineName: json['medicineName'] as String,
        time: DateTime.parse(json['time'] as String),
        createdAt: json['createdAt'] != null
            ? DateTime.parse(json['createdAt'] as String)
            : DateTime.now(),
        fired: json['fired'] as bool? ?? false,
      );
}
