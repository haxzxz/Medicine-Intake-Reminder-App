import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/reminder_log.dart';
import '../services/storage_service.dart';

class ReminderLogScreen extends StatefulWidget {
  const ReminderLogScreen({super.key});

  @override
  State<ReminderLogScreen> createState() => _ReminderLogScreenState();
}

class _ReminderLogScreenState extends State<ReminderLogScreen> {
  List<ReminderLog> _logs = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadLogs();
  }

  Future<void> _loadLogs() async {
    final logs = await StorageService.loadLogs();
    setState(() {
      // Show newest first
      _logs = logs.reversed.toList();
      _loading = false;
    });
  }

  Future<void> _clearAll() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Clear all logs?'),
        content: const Text(
            'This will permanently delete your entire reminder history.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancel')),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            style: FilledButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('Clear'),
          ),
        ],
      ),
    );
    if (confirm == true) {
      await StorageService.clearLogs();
      setState(() => _logs = []);
    }
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    return Scaffold(
      backgroundColor: scheme.surface,
      appBar: AppBar(
        backgroundColor: scheme.surface,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        title: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Reminder Log',
              style:
                  TextStyle(fontWeight: FontWeight.w600, fontSize: 17)),
          Text('${_logs.length} entries',
              style: TextStyle(
                  fontSize: 11,
                  color: scheme.onSurface.withOpacity(0.45),
                  fontWeight: FontWeight.normal)),
        ]),
        actions: [
          if (_logs.isNotEmpty)
            IconButton(
              tooltip: 'Clear all',
              icon: Icon(Icons.delete_sweep_outlined,
                  color: scheme.onSurface.withOpacity(0.5)),
              onPressed: _clearAll,
            ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child:
              Divider(height: 1, color: scheme.outlineVariant.withOpacity(0.3)),
        ),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _logs.isEmpty
              ? _buildEmpty(scheme)
              : _buildList(scheme),
    );
  }

  Widget _buildEmpty(ColorScheme scheme) {
    return Center(
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Container(
          width: 72,
          height: 72,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: const Color(0xFF534AB7).withOpacity(0.08),
          ),
          child: const Icon(Icons.history_rounded,
              size: 36, color: Color(0xFF534AB7)),
        ),
        const SizedBox(height: 16),
        Text('No reminders yet',
            style: TextStyle(
                fontWeight: FontWeight.w500,
                color: scheme.onSurface.withOpacity(0.6))),
        const SizedBox(height: 6),
        Text('Your reminder history will appear here',
            style: TextStyle(
                fontSize: 13, color: scheme.onSurface.withOpacity(0.4))),
      ]),
    );
  }

  Widget _buildList(ColorScheme scheme) {
    // Group by date
    final Map<String, List<ReminderLog>> grouped = {};
    for (final log in _logs) {
      final key = _dateKey(log.firedAt);
      grouped.putIfAbsent(key, () => []).add(log);
    }

    final sections = grouped.entries.toList();

    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 32),
      itemCount: sections.length,
      itemBuilder: (_, i) {
        final section = sections[i];
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Date header
            Padding(
              padding: const EdgeInsets.only(top: 4, bottom: 8),
              child: Text(
                _friendlyDate(section.value.first.firedAt),
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                  color: scheme.onSurface.withOpacity(0.4),
                  letterSpacing: 0.6,
                ),
              ),
            ),
            ...section.value.map((log) => _buildLogCard(log, scheme)),
            const SizedBox(height: 8),
          ],
        );
      },
    );
  }

  Widget _buildLogCard(ReminderLog log, ColorScheme scheme) {
    final timeFmt = DateFormat('h:mm a');
    final isFired = log.status == 'fired';
    final isMissed = log.status == 'missed';
    final isDeleted = log.status == 'deleted';

    Color statusColor = isFired
        ? const Color(0xFF1D9E75)
        : isMissed
            ? Colors.orange
            : scheme.onSurface.withOpacity(0.4);

    IconData statusIcon = isFired
        ? Icons.check_circle_outline_rounded
        : isMissed
            ? Icons.warning_amber_rounded
            : Icons.cancel_outlined;

    String statusLabel = isFired ? 'Taken' : isMissed ? 'Missed' : 'Deleted';

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: scheme.surfaceContainerLowest,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: scheme.outlineVariant.withOpacity(0.25)),
      ),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        // Medicine icon
        Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            color: const Color(0xFF534AB7).withOpacity(0.1),
            borderRadius: BorderRadius.circular(10),
          ),
          child: const Icon(Icons.medication_rounded,
              color: Color(0xFF534AB7), size: 20),
        ),
        const SizedBox(width: 12),

        // Details
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(children: [
                Expanded(
                  child: Text(
                    log.medicineName,
                    style: const TextStyle(
                        fontWeight: FontWeight.w600, fontSize: 14),
                  ),
                ),
                // Status badge
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: statusColor.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Row(mainAxisSize: MainAxisSize.min, children: [
                    Icon(statusIcon, size: 11, color: statusColor),
                    const SizedBox(width: 3),
                    Text(statusLabel,
                        style: TextStyle(
                            fontSize: 11,
                            color: statusColor,
                            fontWeight: FontWeight.w500)),
                  ]),
                ),
              ]),
              const SizedBox(height: 4),
              Row(children: [
                Icon(Icons.schedule_rounded,
                    size: 12, color: scheme.onSurface.withOpacity(0.4)),
                const SizedBox(width: 4),
                Text(
                  'Scheduled ${timeFmt.format(log.scheduledTime)}',
                  style: TextStyle(
                      fontSize: 12, color: scheme.onSurface.withOpacity(0.5)),
                ),
              ]),
              const SizedBox(height: 2),
              Row(children: [
                Icon(Icons.notifications_active_outlined,
                    size: 12, color: scheme.onSurface.withOpacity(0.4)),
                const SizedBox(width: 4),
                Text(
                  'Fired at ${timeFmt.format(log.firedAt)}',
                  style: TextStyle(
                      fontSize: 12, color: scheme.onSurface.withOpacity(0.5)),
                ),
                if (!isFired) ...[
                  const SizedBox(width: 6),
                  Text(
                    _delay(log.scheduledTime, log.firedAt),
                    style: TextStyle(
                        fontSize: 11,
                        color: isMissed ? Colors.orange : statusColor),
                  ),
                ],
              ]),
            ],
          ),
        ),
      ]),
    );
  }

  String _dateKey(DateTime d) =>
      '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  String _friendlyDate(DateTime d) {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final date = DateTime(d.year, d.month, d.day);
    final diff = today.difference(date).inDays;
    if (diff == 0) return 'TODAY';
    if (diff == 1) return 'YESTERDAY';
    return DateFormat('MMMM d, yyyy').format(d).toUpperCase();
  }

  String _delay(DateTime scheduled, DateTime fired) {
    final diff = fired.difference(scheduled);
    if (diff.inMinutes < 1) return '';
    if (diff.inMinutes < 60) return '(+${diff.inMinutes}m late)';
    return '(+${diff.inHours}h late)';
  }
}
